"""
Script to test the Belief Propagation algorithm on a simple graph,
presented in the presentation slides.

@author: Eli
"""

import FactorGraph as fg

# By hand, create a (7,4) Hamming code graph
# with the observed signal 1100011, which
# corresponds to the codeword 1100.

s1 = fg.FactorGraphNode("s1", False)
s2 = fg.FactorGraphNode("s2", False)
s3 = fg.FactorGraphNode("s3", False)
s4 = fg.FactorGraphNode("s4", False)
sNodes = [s1,s2,s3,s4]

f1 = fg.FactorGraphNode("f1", True,     1)
f2 = fg.FactorGraphNode("f1", True,     1)
f3 = fg.FactorGraphNode("f1", True,     0)
f4 = fg.FactorGraphNode("f1", True,     0)
f123 = fg.FactorGraphNode("f123", True, 0)
f234 = fg.FactorGraphNode("f234", True, 1)
f134 = fg.FactorGraphNode("f134", True, 1)
fNodes = [f1,f2,f3,f4,f123,f234,f134]

nodes = sNodes + fNodes

s1.addNeighbor(f1)
s2.addNeighbor(f2)
s3.addNeighbor(f3)
s4.addNeighbor(f4)

f123.addNeighbor(s1)
f123.addNeighbor(s2)
f123.addNeighbor(s3)

f234.addNeighbor(s2)
f234.addNeighbor(s3)
f234.addNeighbor(s4)

f134.addNeighbor(s1)
f134.addNeighbor(s3)
f134.addNeighbor(s4)


# The Belief Propagation algorithm.
# It consists of passing messages among nodes in the graph.
# The message passing scheme I use is to alternate sending
# messages between source nodes and factor nodes.
Nsteps = 10
for step in range(Nsteps):
    for sNode in sNodes:
        for j in sNode.neighbors.iterkeys():
            sNode.updateMessage(j)
            
    for fNode in fNodes:
        for j in fNode.neighbors.iterkeys():
            fNode.updateMessage(j)        
        
for sNode in sNodes:
    marginal = sNode.computeMarginal()
    print 'P(' + sNode.name + ') = ' + str(marginal)
    