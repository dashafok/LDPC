"""

Low density parity check (LDPC) code class. 
Decodes messages using Belief Propagation.

@author: Eli
"""

import FactorGraph as fg
import numpy as np

class LDPC:
    
    # Constructor. Creates a random LDPC with 
    # (numTransmittedBits - numSourceBits) parity-check constraints
    # that involve parityCheckSize bits.
    def __init__(self, numSourceBits, numTransmittedBits, parityCheckSize):
        self.encodingMatrix = np.zeros((numTransmittedBits, numSourceBits))
        self.encodingMatrix[0:numSourceBits, 0:numSourceBits] = np.eye(numSourceBits)
        
        self.sNodes = [] # Source bit variable nodes
        self.fNodes = [] # Factor nodes (associated with transmitted bits)
        
        # Initialize the source bit variable nodes.
        for si in range(numSourceBits):
            sNode = fg.FactorGraphNode('s_' + str(si), False)
            self.sNodes.append(sNode)
        
        # Initialize the transmitted bit factor nodes.
        
        # The redundant factors.
        for si in range(numSourceBits):
            fName = 'f_' + str(si)
            fNode = fg.FactorGraphNode(fName, True)
            fNode.addNeighbor(self.sNodes[si])
            
            self.fNodes.append(fNode)
        
        # The parity check factors.
        numParityChecks = numTransmittedBits-numSourceBits
        for fi in range(numParityChecks):
            # Pick a random set of the source bits to be part of the parity check.
            parityCheckBits = np.random.permutation(numSourceBits)
            parityCheckBits = parityCheckBits[0:parityCheckSize]
            
            fName = 'f'
            for bit in parityCheckBits:
                fName = fName + '_' + str(bit)
            
            fNode = fg.FactorGraphNode(fName, True)
            for bit in parityCheckBits:
                fNode.addNeighbor(self.sNodes[bit])
            
            self.fNodes.append(fNode)
            
            # Sets the appropriate elements of the matrix to 1.
            self.encodingMatrix[numSourceBits+fi, parityCheckBits] = 1
            
    # Sets the observed bits that you measured after the noisy channel.
    def setObservedBits(self, observation):
        for fi in range(len(observation)):
            self.fNodes[fi].factorBit = observation[fi]
            
    # Encodes the source signal into a redundant LDPC transmitted signal.
    def encode(self, source):
        result = np.dot(self.encodingMatrix, source.reshape((len(source), 1))) % 2
        return result.flatten()
        
    # Decodes the transmitted signal using Belief Propagation.
    # Returns a vector of values between 0 and 1 that represent
    # the marginal probabilities of each source bit being 1.
    def decode(self, transmitted, Nsteps=10): 
        self.setObservedBits(transmitted)        
        
        for step in range(Nsteps):
            for sNode in self.sNodes:
                for j in sNode.neighbors.iterkeys():
                    sNode.updateMessage(j)
                    
            for fNode in self.fNodes:
                for j in fNode.neighbors.iterkeys():
                    fNode.updateMessage(j)    
                    
        marginalProbabilities = np.zeros(len(self.sNodes))
        for si in range(len(self.sNodes)):
            marginalVector = self.sNodes[si].computeMarginal()
            marginalProbabilities[si] = marginalVector[1]
            
        return marginalProbabilities