"""
Factor graph class used to perform Belief Propagation.

@author: Eli
"""

import numpy as np
import itertools as it

# A node in the factor graph of a parity check linear block code graph. 
# There are two types of nodes, variable and factor nodes, distinguished 
# by the isFactor flag.
class FactorGraphNode:
    
    # Constructor. Each node has a name, knows whether or not it
    # is a factor, and if it is a factor has an associated fixed bit
    # for the parity check function.
    def __init__(self, name, isFactor, factorBit=0):
        self.name      = name
        self.neighbors = dict() # Dictionary of neighboring nodes (keys are node names).
        self.messages  = dict() # Dictionary of messages to neighboring nodes.
        self.isFactor  = isFactor
        self.factorBit = factorBit
        
    # Adds a neighboring node and initializes the messages to one
    # to and from the neighboring node.
    def addNeighbor(self, node):
        self.neighbors[node.name] = node
        self.messages[node.name]  = np.array([1.0, 1.0])
        node.neighbors[self.name] = self
        node.messages[self.name]  = np.array([1.0, 1.0])
        
    # Returns whether the node is a leaf of the graph.
    def isLeaf(self):
        return len(self.neighbors) <= 1        
        
    # Updates the message from the current node i to neighboring node j.
    def updateMessage(self, j):
        if self.isFactor:
            self.messages[j] = self.computeFactorMessage(j)
        else:
            self.messages[j] = self.computeNodeMessage(j)
    
    # Computes the message from the current variable node i to factor node j.
    def computeNodeMessage(self, j):
        i = self.name 
        
        prodMessagesToI = np.ones(2) # Should this be self.messages[j] ?
        for ip in self.neighbors.iterkeys():
            if ip != j:
                prodMessagesToI *= self.neighbors[ip].messages[i]
                 
        # Normalization of messages to prevent overflow.
        if np.sum(prodMessagesToI) != 0.0:
            result = prodMessagesToI / np.sum(prodMessagesToI)
        else:
            # If a parity-check constraint cannot be satisfied,
            # I assume that both binary configurations are equally possible.
            result = 0.5*np.ones(2)
            
        return result
            
    # Computes the message from the current factor node i to variable node j.
    def computeFactorMessage(self, j):
        i = self.name        
        
        # Generate a list of possible binary configurations of neighboring nodes
        # excluding node j.
        numVars = len(self.neighbors)-1
        binaryNums = list(it.product([0, 1], repeat=numVars))
        
        result = np.zeros(2)        
        
        # Marginalize (sum) over possible binary configurations of the
        # variables in neighboring nodes, except for node j.
        for binaryNum in binaryNums:
            index = 0
            
            # Explicit parity-check constraint
            summand = np.array([1.0, 0.0])
            if (np.sum(binaryNum) + self.factorBit) % 2 == 1:
                summand = np.array([0.0, 1.0])
            
            for ip in self.neighbors.iterkeys():
                if ip != j:
                    summand *= (self.neighbors[ip].messages[i])[binaryNum[index]]
                    index += 1 # Assumes the key list is always iterated over in the same order
            
            result += summand
            
        return result
        
    # Computes the marginal probability for the random variable in the current node.
    # Use after the messages have been computed from the BP algorithm.
    def computeMarginal(self):
        i = self.name
        prodMessagesToI = np.ones(2)
        for ip in self.neighbors.iterkeys():
            prodMessagesToI *= self.neighbors[ip].messages[i]
            
        if np.sum(prodMessagesToI) != 0.0:
            result = prodMessagesToI / np.sum(prodMessagesToI)
        else:
            result = 0.5 * np.ones(2)
        
        return result
        
    