"""

Tests of the low-density parity check code (LDPC) class.

First test: Encode and decode an image with no noise added.

Second test: Encode an image, add noise, and then decode. 
See how well the decoded image looks.

@author: Eli
"""

import LDPC as lc
import matplotlib.pyplot as plt
import matplotlib
import scipy
import numpy as np

matplotlib.rc('font', size=35)
matplotlib.rc('xtick', labelsize=35) 
matplotlib.rc('ytick', labelsize=35) 

image = scipy.misc.imread('googlelogo_white.png', mode='L')
image = scipy.misc.imresize(image, 0.1)
image = np.ceil(image.astype(float) / np.max(image) - 0.36)

#image = np.zeros((4,8))
#image[2:,0:2] = np.ones((2,2))

Ly, Lx = image.shape
numSourceBits = Lx*Ly
rate = 2 # redundancy of encoding
numTransmittedBits = rate * numSourceBits

parityCheckSize = 5

code = lc.LDPC(numSourceBits, numTransmittedBits, parityCheckSize)

plt.figure(1)
# A sparisty pattern of the encoding matrix of the LDPC code.
plt.spy(code.encodingMatrix, markersize=2)

### FIRST TEST ###
#plt.figure()
encodedSignal = code.encode(image.flatten())
#plt.imshow(encodedSignal.reshape((rate*Ly,Lx)), cmap='Greys', interpolation='none')

decodedSignal = code.decode(encodedSignal, Nsteps=2)

plt.figure(2)
plt.subplot(1,2,1)
plt.imshow(encodedSignal.reshape((rate*Ly, Lx)), cmap='Greys', interpolation='none')
plt.subplot(1,2,2)
plt.imshow(decodedSignal.reshape((Ly,Lx)), cmap='Greys', interpolation='none')
plt.savefig('LDPCTest1.png')


### SECOND TEST ###
f = 0.03 # percent chance of a bit being corrupted in the noisy channel

encodedSignal  = code.encode(image.flatten())
degradedSignal = (encodedSignal + np.random.choice([0, 1], size=(numTransmittedBits,), p=[1-f, f])) % 2
decodedSignal  = code.decode(degradedSignal, Nsteps=100)

plt.figure(3)
plt.subplot(1,4,1)
plt.imshow(encodedSignal.reshape((rate*Ly,Lx)), cmap='Greys', interpolation='none')
plt.subplot(1,4,2)
plt.imshow(degradedSignal.reshape((rate*Ly,Lx)), cmap='Greys', interpolation='none')
plt.subplot(1,4,3)
plt.imshow(decodedSignal.reshape((Ly,Lx)), cmap='Greys', interpolation='none')
plt.subplot(1,4,4)
plt.imshow(decodedSignal.reshape((Ly,Lx)) > 0.5, cmap='Greys', interpolation='none')


plt.savefig('LDPCTest2.png')


