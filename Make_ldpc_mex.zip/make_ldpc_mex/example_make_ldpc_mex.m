checkMatrix = make_ldpc_mex(12, 16, 3);
disp(full(checkMatrix));